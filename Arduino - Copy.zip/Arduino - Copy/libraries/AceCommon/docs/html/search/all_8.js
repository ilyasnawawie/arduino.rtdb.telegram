var searchData=
[
  ['kcstringtype_44',['kCStringType',['../classace__common_1_1FCString.html#a4532428b47a87556510765abaabcefd3',1,'ace_common::FCString']]],
  ['kfstringtype_45',['kFStringType',['../classace__common_1_1FCString.html#ae9df90f7862d0a69e6e4e3f2febaf9d6',1,'ace_common::FCString']]],
  ['kstring_46',['KString',['../classace__common_1_1KString.html',1,'ace_common::KString'],['../classace__common_1_1KString.html#a1ac7be10f8d055edde05aaa1e1067bc4',1,'ace_common::KString::KString(const char *s, const char *const *keywords, uint8_t numKeywords)'],['../classace__common_1_1KString.html#a60615a796754fa50206fefa0c328fdb9',1,'ace_common::KString::KString(const __FlashStringHelper *fs, const char *const *keywords, uint8_t numKeywords)']]],
  ['kstringiterator_47',['KStringIterator',['../classace__common_1_1KStringIterator.html',1,'ace_common::KStringIterator'],['../classace__common_1_1KStringIterator.html#a45f976943f86ba82cc4750e36af0cd3d',1,'ace_common::KStringIterator::KStringIterator()']]]
];
